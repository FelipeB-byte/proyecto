from django.contrib import admin
from .models import Cancha, Reserva
admin.site.register(Cancha)
admin.site.register(Reserva)
